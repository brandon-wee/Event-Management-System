package com.fit2081.fit2081a1;

import java.util.ArrayList;

public class KeyStore {
    public static String FILE_NAME = "UNIQUE_FILE_NAME";
    public static String KEY_USERNAME = "KEY_USERNAME";
    public static String KEY_PASSWORD = "KEY_PASSWORD";
    public static String KEY_CATEGORY_ID = "KEY_CATEGORY_ID";
    public static String KEY_CATEGORY_NAME = "KEY_CATEGORY_NAME";
    public static String KEY_CATEGORY_EVENT_COUNT = "KEY_CATEGORY_EVENT_COUNT";
    public static String KEY_CATEGORY_IS_ACTIVE = "KEY_CATEGORY_IS_ACTIVE";
    public static String KEY_EVENT_ID = "KEY_EVENT_ID";
    public static String KEY_EVENT_NAME = "KEY_EVENT_NAME";
    public static String KEY_EVENT_TICKETS_AVAILABLE = "KEY_EVENT_TICKETS_AVAILABLE";
    public static String KEY_EVENT_IS_ACTIVE = "KEY_EVENT_TICKETS_AVAILABLE";
    public static String KEY_EVENT_ARRAYLIST = "KEY_EVENT_ARRAYLIST";
    public static String KEY_CATEGORY_ARRAYLIST = "KEY_CATEGORY_ARRAYLIST";


}

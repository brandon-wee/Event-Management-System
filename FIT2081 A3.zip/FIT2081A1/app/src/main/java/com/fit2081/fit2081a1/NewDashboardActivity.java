package com.fit2081.fit2081a1;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

public class NewDashboardActivity extends AppCompatActivity {


    private DrawerLayout drawerlayout;
    private NavigationView navigationView;
    Toolbar toolbar;


//    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.drawer_layout);

        drawerlayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerlayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerlayout.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(new MyNavigationListener());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Undo", null).show();
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu, menu);
        return true;
    }

//    View.OnClickListener undoOnClickListener = new View.OnClickListener() {
//        @Override
//        public void onClick(View view) {
//            listItems.remove(listItems.size() -1);
//            adapter.notifyDataSetChanged();
//        }
//    };
    class MyNavigationListener implements NavigationView.OnNavigationItemSelectedListener {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            // get the id of the selected item
            int id = item.getItemId();

            if (id == R.id.view_all_categories) {
                // Do something
                Intent intent_user_details = new Intent(getApplicationContext(), ListCategoryActivity.class);

                startActivity(intent_user_details);
            } else if (id == R.id.add_category) {
                // Do something
                Intent intent_user_details = new Intent(getApplicationContext(), EventCategoryActivity.class);

                startActivity(intent_user_details);
            } else if (id == R.id.view_all_events) {
                // Do something sussy
                Intent intent_user_details = new Intent(getApplicationContext(), ListEventActivity.class);

                startActivity(intent_user_details);
            } else if (id == R.id.logout) {
                // Do even sussier stuff
                finish();
            }
            // close the drawer
            drawerlayout.closeDrawers();
            // tell the OS
            return true;
        }
    }
    public static boolean isAlphaOrAlphanumeric(String str) {
        boolean hasAlphabetic = false;
        boolean hasNumeric = false;
        for (char c : str.toCharArray()) {
            if (Character.isLetter(c)) {
                hasAlphabetic = true;
            } else if (Character.isDigit(c)) {
                hasNumeric = true;
            } else {
                return false;
            }
        }
        return hasAlphabetic && hasNumeric;
    }

}
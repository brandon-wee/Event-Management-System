package com.fit2081.fit2081a1;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.fit2081.fit2081a1.provider.CategoryViewModel;
import com.fit2081.fit2081a1.provider.EventCategory;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link FragmentListCategory#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FragmentListCategory extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public FragmentListCategory() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment FragmentListCategory.
     */
    // TODO: Rename and change types and number of parameters
    public static FragmentListCategory newInstance(String param1, String param2) {
        FragmentListCategory fragment = new FragmentListCategory();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }
    ArrayList<EventCategory> listCategories;
    Gson gson;
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    CategoryRecyclerAdapter adapter;

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        gson = new Gson();
        View view = inflater.inflate(R.layout.fragment_list_category, container, false);

        recyclerView = view.findViewById(R.id.category_recycler_view);

        layoutManager = new LinearLayoutManager(getActivity().getApplicationContext());  //A RecyclerView.LayoutManager implementation which provides similar functionality to ListView.
        recyclerView.setLayoutManager(layoutManager);   // Also StaggeredGridLayoutManager and GridLayoutManager or a custom Layout manager


        adapter = new CategoryRecyclerAdapter();
        recyclerView.setAdapter(adapter);

        refresh();
        return view;
    }
//    public void restoreArrayListAsText() {
//        SharedPreferences sharedPreferences = getContext().getSharedPreferences(KeyStore.FILE_NAME, Context.MODE_PRIVATE);
//        String arrayListStringRestored = sharedPreferences.getString(KeyStore.KEY_CATEGORY_ARRAYLIST, "[]");
//        Type type = new TypeToken<ArrayList<EventCategory>>() {}.getType();
//        listCategories = gson.fromJson(arrayListStringRestored, type);
//    }

    public void restoreArrayListFromDatabase() {
        CategoryViewModel viewModel = new ViewModelProvider(this).get(CategoryViewModel.class);
        viewModel.getAllCategory().observe(this.getActivity(), newData -> {

            listCategories = new ArrayList<EventCategory>();
            EventCategory header = new EventCategory("", "", 0, false, "");
            header.setHeader();
            listCategories.add(header);
            listCategories.addAll(newData);
            Log.v("TAG", listCategories.toString());
            adapter.setData(listCategories);
            adapter.notifyDataSetChanged();
        });
    }
    public void refresh() {
        restoreArrayListFromDatabase();
        adapter.setData(listCategories);
        adapter.notifyDataSetChanged();
    }

}
package com.fit2081.fit2081a1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.security.Key;

public class LoginActivity extends AppCompatActivity {
    EditText etLoginUsername;
    EditText etLoginPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etLoginUsername = findViewById(R.id.editTextLoginUsername);
        etLoginPassword = findViewById(R.id.editTextLoginPassword);

        SharedPreferences sharedPreferences = getSharedPreferences(KeyStore.FILE_NAME, MODE_PRIVATE);

        // save key-value pairs to the shared preference file
        String usernameRestored = sharedPreferences.getString(KeyStore.KEY_USERNAME, "");

        etLoginUsername.setText(usernameRestored);
    }

    public void onClickLogin(View view) {
        String str_username = "", str_password = "";

        str_username = etLoginUsername.getText().toString();
        str_password = etLoginPassword.getText().toString();

        SharedPreferences sharedPreferences = getSharedPreferences(KeyStore.FILE_NAME, MODE_PRIVATE);

        // save key-value pairs to the shared preference file
        String usernameRestored = sharedPreferences.getString(KeyStore.KEY_USERNAME, "");
        String passwordRestored = sharedPreferences.getString(KeyStore.KEY_PASSWORD, "");

        if (str_username.isEmpty() || str_password.isEmpty() || ! str_username.equals(usernameRestored) || ! str_password.equals(passwordRestored)) {
            Toast.makeText(getApplicationContext(), "Authentication failure: Username or Password incorrect", Toast.LENGTH_SHORT).show();
            return;
        } else {
            Toast.makeText(getApplicationContext(), "Authentication success! Redirecting to dashboard!", Toast.LENGTH_SHORT).show();

            Intent intent_user_details = new Intent(getApplicationContext(), EventActivity.class);

            startActivity(intent_user_details);

            finish();
        }
    }

    public void onClickSignUp(View view) {
        finish();
    }
}
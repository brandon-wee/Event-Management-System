package com.fit2081.fit2081a1.provider;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.ArrayList;
import java.util.List;

@Dao
public interface EventCategoryDao {
    @Query("select * from category")
    LiveData<List<EventCategory>> getAllCategories();

    @Query("select * from category where category_id=:category_ID")
    List<EventCategory> getCategoryID(String category_ID);

    @Insert
    void addCategory(EventCategory category);

    @Query("delete from category where category_id=:category_ID")
    void deleteCategory(String category_ID);

    @Query("delete from category")
    void deleteAllCategories();

    @Query("UPDATE category SET event_count = event_count + 1 WHERE category_id=:category_ID")
    void incrementEventCount(String category_ID);

    @Query("UPDATE category SET event_count = event_count - 1 WHERE category_id=:category_ID")
    void decrementEventCount(String category_ID);

}

package com.fit2081.fit2081a1.provider;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.ArrayList;
import java.util.List;

public class CategoryViewModel extends AndroidViewModel {

    private CategoryRepository mRepository;

    private LiveData<List<EventCategory>> mAllCategory;


    public CategoryViewModel(@NonNull Application application) {
        super(application);
        mRepository = new CategoryRepository(application);
        mAllCategory = mRepository.getAllCategory();
    }

    public LiveData<List<EventCategory>> getAllCategory() {
        return mAllCategory;
    }

    public List<EventCategory> getCategoryByID(String category_ID) {
        return mRepository.getCategoryByID(category_ID);
    }
    public void insert(EventCategory category) {
        mRepository.insert(category);
    }

    public void deleteCategory(String category_ID) {
        mRepository.deleteCategory(category_ID);
    }

    public void deleteAllCategory() {
        mRepository.deleteAllCategory();
    }

    public void incrementEventCount(String categoryId) {
        mRepository.incrementEventCount(categoryId);
    }
    public void decrementEventCount(String categoryId) {
        mRepository.decrementEventCount(categoryId);
    }

}

package com.fit2081.fit2081a1;

import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.fit2081.fit2081a1.provider.Event;

import java.util.ArrayList;

public class EventRecyclerAdapter extends RecyclerView.Adapter<EventRecyclerAdapter.CustomViewHolder> {

    ArrayList<Event> data = new ArrayList<Event>();
    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.event_card_layout, parent, false);
        CustomViewHolder viewHolder = new CustomViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder holder, int position) {
        Log.v("TAG", data.toString());
        Log.v("TAG", data.get(position).getEvent_name());
        holder.tvEventID.setText(data.get(position).getEvent_id());
        holder.tvCategoryID.setText(data.get(position).getCategory_id());
        holder.tvEventName.setText(data.get(position).getEvent_name());
        holder.tvTicket.setText(String.valueOf(data.get(position).getTickets_available()));
        if (data.get(position).isIs_active()) {
            holder.tvActive.setText("Active");
        } else {
            holder.tvActive.setText("Inactive");
        }

        holder.tvColor.setBackgroundColor(data.get(position).getColor());

        final int fPosition = position;
        holder.itemView.setOnClickListener(new View.OnClickListener() { //set back to itemView for students
            @Override
            public void onClick(View v) {
                Intent intent_user_details = new Intent(v.getContext(), EventWebViewActivity.class);
                intent_user_details.putExtra("name", data.get(position).getEvent_name());

                v.getContext().startActivity(intent_user_details);
            }
        });
    }

    @Override
    public int getItemCount() {
        if (this.data != null) { // if data is not null
            return this.data.size(); // then return the size of ArrayList
        }

        // else return zero if data is null
        return 0;
    }

    public void setData(ArrayList<Event> data) {
        this.data = data;
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder {

        public TextView tvEventID;
        public TextView tvCategoryID;
        public TextView tvEventName;
        public TextView tvTicket;
        public TextView tvActive;
        public TextView tvColor;

        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);
            tvEventID = itemView.findViewById(R.id.tv_event_id);
            tvCategoryID = itemView.findViewById(R.id.tv_event_category_id);
            tvEventName = itemView.findViewById(R.id.tv_event_name);
            tvTicket = itemView.findViewById(R.id.tv_tickets);
            tvActive = itemView.findViewById(R.id.tv_event_active);
            tvColor = itemView.findViewById(R.id.event_color_strip);
        }
    }

}

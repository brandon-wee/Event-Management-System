package com.fit2081.fit2081a1.provider;

import android.graphics.Color;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.Random;

@Entity(tableName = "category")
public class EventCategory {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    @NonNull
    private int id;
    @ColumnInfo(name = "category_id")
    @NonNull
    private String category_id;
    @ColumnInfo(name = "category_name")
    @NonNull
    private String category_name;
    @ColumnInfo(name = "event_count")
    @NonNull
    private int event_count;
    @ColumnInfo(name = "is_active")
    @NonNull
    private boolean is_active;
    @ColumnInfo(name = "color")
    @NonNull
    private int color;
    @ColumnInfo(name = "header")
    @NonNull
    private boolean header = false;
    @ColumnInfo(name = "location")
    @NonNull
    private String location;

    public EventCategory(String category_id, String category_name, int event_count, boolean is_active, String location) {
        this.category_id = category_id;
        this.category_name = category_name;
        this.event_count = event_count;
        this.is_active = is_active;
        this.color = generateRandomColor();
        this.location = location;
    }

    public void setHeader(boolean header) {
        this.header = header;
    }

    public int getId() {
        return id;
    }

    public void setId(@NonNull int id) {
        this.id = id;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getCategory_id() {
        return category_id;
    }

    public void setCategory_id(String category_id) {
        this.category_id = category_id;
    }

    public String getCategory_name() {
        return category_name;
    }

    public void setCategory_name(String category_name) {
        this.category_name = category_name;
    }

    public int getEvent_count() {
        return event_count;
    }

    public void setEvent_count(int event_count) {
        this.event_count = event_count;
    }

    public boolean isIs_active() {
        return is_active;
    }

    public void setIs_active(boolean is_active) {
        this.is_active = is_active;
    }

    public void incrementEventCount() {
        event_count++;
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }

    public void decrementEventCount() {
        Log.v("TAG", String.valueOf(event_count));
        event_count--;
        Log.v("TAG", String.valueOf(event_count));
    }
    public int generateRandomColor() {
        Random random = new Random();
        int red = random.nextInt(206) + 50;
        int green = random.nextInt(206) + 50;
        int blue = random.nextInt(206) + 50;

        return Color.rgb(red, green, blue);
    }

    public void setHeader() {
        header = true;
    }
    public boolean isHeader() {
        return header;
    }

    @Override
    public String toString() {
        return "EventCategory{" +
                "id=" + id +
                ", category_id='" + category_id + '\'' +
                ", category_name='" + category_name + '\'' +
                ", event_count=" + event_count +
                ", is_active=" + is_active +
                ", color=" + color +
                ", header=" + header +
                ", location='" + location + '\'' +
                '}';
    }
}

package com.fit2081.fit2081a1.provider;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class EventViewModel extends AndroidViewModel {

    private EventRepository mRepository;

    private LiveData<List<Event>> mAllEvents;

    public EventViewModel(@NonNull Application application) {
        super(application);
        mRepository = new EventRepository(application);
        mAllEvents = mRepository.getAllEvent();
    }

    public LiveData<List<Event>> getAllEvent() {
        return mAllEvents;
    }

    public void insert(Event event) {
        mRepository.insert(event);
    }

    public void deleteEvent(String event_ID) {
        mRepository.deleteEvent(event_ID);
    }

    public void deleteAllEvent() {
        mRepository.deleteAllEvent();
    }

    public List<Event> getEventByID(String eventID) {
        return mRepository.getEventID(eventID);
    }
}

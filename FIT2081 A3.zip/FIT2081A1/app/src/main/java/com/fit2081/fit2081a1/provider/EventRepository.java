package com.fit2081.fit2081a1.provider;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.ArrayList;
import java.util.List;

public class EventRepository {
    private EventDao mEventDao;
    private LiveData<List<Event>> mAllEvent;
    EventRepository (Application application) {
        A3Database db = A3Database.getDatabase(application);
        mEventDao = db.eventDao();
        mAllEvent = mEventDao.getAllEvents();
    }

    LiveData<List<Event>> getAllEvent() {
        return mAllEvent;
    }
    List<Event> getEventID(String event_ID) {
        return mEventDao.getEventID(event_ID);
    }
    void insert(Event event) {
        A3Database.databaseWriteExecutor.execute(() -> mEventDao.addEvent(event));
    }

    void deleteEvent(String event_ID) {
        A3Database.databaseWriteExecutor.execute(() -> mEventDao.deleteEvent(event_ID));
    }

    void deleteAllEvent() {
        A3Database.databaseWriteExecutor.execute(() -> mEventDao.deleteAllEvents());
    }
}

package com.fit2081.fit2081a1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.lifecycle.ViewModelProvider;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import com.fit2081.fit2081a1.provider.CategoryViewModel;
import com.fit2081.fit2081a1.provider.Event;
import com.fit2081.fit2081a1.provider.EventCategory;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Random;

public class EventCategoryActivity extends AppCompatActivity {

    EditText etCategoryName;
    EditText etEventCount;
    Switch switchActive;
    EditText etCategoryID;
    EditText etLocation;
    EventCategoryActivity.MyBroadCastReceiver myBroadCastReceiver;
    Gson gson;
    CategoryViewModel viewModel;
    private boolean isReceiverRegistered = false;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_event_category);
        etCategoryName = findViewById(R.id.editTextCategoryName);
        etEventCount = findViewById(R.id.editTextEventCount);
        switchActive = findViewById(R.id.switchActive);
        etCategoryID = findViewById(R.id.editTextCategoryID);
        etLocation = findViewById(R.id.editTextLocation);
        viewModel = new ViewModelProvider(this).get(CategoryViewModel.class);

        /* Request permissions to access SMS */
        ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.SEND_SMS, android.Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS}, 0);
        /* Create and instantiate the local broadcast receiver
           This class listens to messages come from class SMSReceiver
         */
        myBroadCastReceiver = new EventCategoryActivity.MyBroadCastReceiver();

        /*
         * Register the broadcast handler with the intent filter that is declared in
         * class SMSReceiver @line 11
         * */

        gson = new Gson();
    }

    public void onClickCreateNewEventCategory(View view) {
        String activeStr = switchActive.isChecked() ? "true" : "false";
        String [] tokens = {etCategoryName.getText().toString(), etEventCount.getText().toString(), activeStr};
        if (validateTokens(tokens)) {
            String categoryID = generateCategoryID();
            etCategoryID.setText(categoryID);
            saveDataToDatabase(categoryID, etCategoryName.getText().toString(), Integer.parseInt(etEventCount.getText().toString().equals("") ? "0" : etEventCount.getText().toString()), switchActive.isChecked(), etLocation.getText().toString());
            Toast.makeText(getApplicationContext(), "Category saved successfully: " + categoryID, Toast.LENGTH_SHORT).show();
            finish();
        }
    }
    class MyBroadCastReceiver extends BroadcastReceiver {

        /*
         * This method 'onReceive' will get executed every time class SMSReceive sends a broadcast
         * */
        @Override
        public void onReceive(Context context, Intent intent) {
            /*
             * Retrieve the message from the intent
             * */
            String msg = intent.getStringExtra(SMSReceiver.SMS_MSG_KEY);
            /*
             * String Tokenizer is used to parse the incoming message
             * The protocol is to have the account holder name and account number separate by a semicolon
             * */

            checkBroadcastMessage(msg);
        }

    }
    private String generateCategoryID() {
        StringBuilder newCategoryID = new StringBuilder();
        Random randomizer = new Random();

        newCategoryID.append('C');
        for (int i = 0; i < 2; i++) {
            newCategoryID.append((char) (randomizer.nextInt(26) + 'A'));
        }
        newCategoryID.append('-');
        for (int i = 0; i < 4; i++) {
            newCategoryID.append((char) (randomizer.nextInt(10) + '0'));
        }
        return newCategoryID.toString();
    }
    private boolean validateTokens(String [] tokens) {
        for (int i = 0; i < tokens.length; i++)
            if (i == 0) {
                if (tokens[0].equals("")) {
                    Toast.makeText(getApplicationContext(), "Category name should not be empty!", Toast.LENGTH_SHORT).show();
                    return false;
                } else if (!isAlphaOrAlphanumeric(tokens[0])) {
                    Toast.makeText(getApplicationContext(), "Invalid Category Name!", Toast.LENGTH_SHORT).show();
                    return false;
                }
            } else if (i == 1) {
                try {
                    if (!tokens[1].equals("") && Integer.parseInt(tokens[1]) <= 0) {
                        Toast.makeText(getApplicationContext(), "Event count should be positive!", Toast.LENGTH_SHORT).show();
                        return false;
                    }
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Invalid event count!", Toast.LENGTH_SHORT).show();
                    return false;
                }
            } else if (!(tokens[2].equalsIgnoreCase("true") || tokens[2].equalsIgnoreCase("false") || tokens[2].equals(""))) {
                Toast.makeText(getApplicationContext(), "Invalid is active value!", Toast.LENGTH_SHORT).show();
                return false;
            }
        return true;
    }
//    private void saveDataToSharedPreference(String categoryID, String categoryName, int count, boolean active){
//        EventCategory newCategory = new EventCategory(categoryID, categoryName, count, active);
//        listCategories.add(newCategory);
//        SharedPreferences sharedPreferences = getSharedPreferences(KeyStore.FILE_NAME, MODE_PRIVATE);
//
//        SharedPreferences.Editor editor = sharedPreferences.edit();
//
//        String arrayListString = gson.toJson(listCategories);
//
//        editor.putString(KeyStore.KEY_CATEGORY_ARRAYLIST, arrayListString);
//        editor.apply();
//
//    }
    private void saveDataToDatabase(String categoryID, String categoryName, int count, boolean active, String location) {
        EventCategory category = new EventCategory(categoryID, categoryName, count, active, location);
        viewModel.insert(category);
    }
    public void onClickBack(View view) {
        Intent resultIntent = new Intent();
        setResult(Activity.RESULT_OK, resultIntent);
        finish();
    }
    private void checkBroadcastMessage(String msg) {
        String [] tokens = new String [3];

        int count = 0;
        StringBuilder token = new StringBuilder();

        for (int i = 0; i < msg.length(); i++) {
            if (msg.charAt(i) == ':' && count == 0) {
                if (!token.toString().equals("category")) {
                    Toast.makeText(getApplicationContext(), "Message should begin with 'category'!", Toast.LENGTH_SHORT).show();
                    return;
                }
                token.setLength(0);
                count += 1;
            } else if (msg.charAt(i) == ';') {
                if (count == 0) {
                    Toast.makeText(getApplicationContext(), "Invalid message format!", Toast.LENGTH_SHORT).show();
                    return;
                } else if (count > 3) {
                    Toast.makeText(getApplicationContext(), "Invalid message format!", Toast.LENGTH_SHORT).show();
                    return;
                }
                tokens[count - 1] = token.toString();
                token.setLength(0);
                count += 1;
            } else {
                token.append(msg.charAt(i));
            }
        }

        tokens[2] = token.toString();
        if (validateTokens(tokens)) {
            etCategoryName.setText(tokens[0]);
            etEventCount.setText(tokens[1]);
            switchActive.setChecked(tokens[2].equalsIgnoreCase("true"));
        }
    }
    @Override
    protected void onStart() {
        super.onStart();
        if (!isReceiverRegistered) {
            registerReceiver(myBroadCastReceiver, new IntentFilter(SMSReceiver.SMS_FILTER), RECEIVER_EXPORTED);
            isReceiverRegistered = true;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (isReceiverRegistered) {
            unregisterReceiver(myBroadCastReceiver);
            isReceiverRegistered = false;
        }
    }
    public boolean isAlphaOrAlphanumeric(String str) {
        boolean hasAlphabetic = false;
        for (char c : str.toCharArray()) {
            if (Character.isLetter(c)) {
                hasAlphabetic = true;
            } else if (!Character.isDigit(c) && c != ' '){
                return false;
            }
        }
        return hasAlphabetic;
    }


//    public void restoreArrayListAsText() {
//        SharedPreferences sharedPreferences = getSharedPreferences(KeyStore.FILE_NAME, MODE_PRIVATE);
//        String arrayListStringRestored = sharedPreferences.getString(KeyStore.KEY_CATEGORY_ARRAYLIST, "[]");
//        Type type = new TypeToken<ArrayList<EventCategory>>() {}.getType();
//        listCategories = gson.fromJson(arrayListStringRestored, type);
//    }
}
package com.fit2081.fit2081a1.provider;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

@Dao
public interface EventDao {
    @Query("select * from event")
    LiveData<List<Event>> getAllEvents();

    @Query("select * from event where event_id=:event_ID")
    List<Event> getEventID(String event_ID);

    @Insert
    void addEvent(Event event);

    @Query("delete from event where event_id=:event_ID")
    void deleteEvent(String event_ID);

    @Query("delete from event")
    void deleteAllEvents();
}

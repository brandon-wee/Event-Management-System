package com.fit2081.fit2081a1.provider;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "event")
public class Event {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    @NonNull
    private int id;
    @ColumnInfo(name = "event_name")
    @NonNull
    private String event_name;
    @ColumnInfo(name = "event_id")
    @NonNull
    private String event_id;
    @ColumnInfo(name = "category_id")
    @NonNull
    private String category_id;
    @ColumnInfo(name = "tickets_available")
    private int tickets_available;
    @ColumnInfo(name = "is_active")
    private boolean is_active;
    @ColumnInfo(name = "color")
    private int color;

    public Event(String event_id, String category_id, String event_name, int tickets_available, boolean is_active, int color) {
        this.event_name = event_name;
        this.event_id = event_id;
        this.category_id = category_id;
        this.tickets_available = tickets_available;
        this.is_active = is_active;
        this.color = color;
    }

    public int getId() {
        return id;
    }

    public void setId(@NonNull int id) {
        this.id = id;
    }

    public String getEvent_name() {
        return event_name;
    }

    public void setEvent_name(String event_name) {
        this.event_name = event_name;
    }

    public String getEvent_id() {
        return event_id;
    }

    public void setEvent_id(String event_id) {
        this.event_id = event_id;
    }

    public String getCategory_id() {
        return category_id;
    }

    public void setCategory_id(String category_id) {
        this.category_id = category_id;
    }

    public int getTickets_available() {
        return tickets_available;
    }

    public void setTickets_available(int tickets_available) {
        this.tickets_available = tickets_available;
    }

    public boolean isIs_active() {
        return is_active;
    }

    public void setIs_active(boolean is_active) {
        this.is_active = is_active;
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }

    @Override
    public String toString() {
        return "Event{" +
                "event_name='" + event_name + '\'' +
                ", event_id='" + event_id + '\'' +
                ", category_id='" + category_id + '\'' +
                ", tickets_available=" + tickets_available +
                ", is_active=" + is_active +
                '}';
    }
}

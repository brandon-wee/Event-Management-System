package com.fit2081.fit2081a1.provider;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;

public class CategoryRepository {
    private EventCategoryDao mCategoryDao;
    private LiveData<List<EventCategory>> mAllCategory;
    CategoryRepository (Application application) {
        A3Database db = A3Database.getDatabase(application);
        mCategoryDao = db.categoryDao();
        mAllCategory = mCategoryDao.getAllCategories();
    }

    LiveData<List<EventCategory>> getAllCategory() {
        return mAllCategory;
    }

    List<EventCategory> getCategoryByID(String category_ID) {
        return mCategoryDao.getCategoryID(category_ID);
    }
    void insert(EventCategory category) {
        A3Database.databaseWriteExecutor.execute(() -> mCategoryDao.addCategory(category));
    }

    void deleteCategory(String category_ID) {
        A3Database.databaseWriteExecutor.execute(() -> mCategoryDao.deleteCategory(category_ID));
    }

    void deleteAllCategory() {
        A3Database.databaseWriteExecutor.execute(() -> mCategoryDao.deleteAllCategories());
    }

    void incrementEventCount(String categoryId) {
        A3Database.databaseWriteExecutor.execute(() -> mCategoryDao.incrementEventCount(categoryId));
    }

    void decrementEventCount(String categoryId) {
        A3Database.databaseWriteExecutor.execute(() -> mCategoryDao.decrementEventCount(categoryId));
    }

}

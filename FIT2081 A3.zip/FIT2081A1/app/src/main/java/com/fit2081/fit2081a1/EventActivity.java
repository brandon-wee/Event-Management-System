package com.fit2081.fit2081a1;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.fit2081.fit2081a1.provider.CategoryViewModel;
import com.fit2081.fit2081a1.provider.Event;
import com.fit2081.fit2081a1.provider.EventCategory;
import com.fit2081.fit2081a1.provider.EventViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;

import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

public class EventActivity extends AppCompatActivity {

    EditText etCategoryID;
    EditText etEventName;
    EditText etTicketAvailable;
    Switch switchEventActive;
    EditText etEventID;
    EventActivity.MyBroadCastReceiver myBroadCastReceiver;
    private DrawerLayout drawerlayout;
    private NavigationView navigationView;
    Toolbar toolbar;
    Gson gson;
    FragmentListCategory fragmentListCategory;
    FragmentManager fragmentManager;
    EventViewModel eventViewModel;
    CategoryViewModel categoryViewModel;
    String lastEventStored;
    View touchpad;
    TextView gestureTypeTv;
    private GestureDetector mDetector;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.drawer_layout);

        /* Obtain views */
        etCategoryID = findViewById(R.id.editTextEventCategoryID);
        etEventName = findViewById(R.id.editTextEventName);
        etTicketAvailable = findViewById(R.id.editTextTicketAvailable);
        switchEventActive = findViewById(R.id.switchEventActive);
        etEventID = findViewById(R.id.editTextEventID);

        eventViewModel = new ViewModelProvider(this).get(EventViewModel.class);
        categoryViewModel = new ViewModelProvider(this).get(CategoryViewModel.class);

        touchpad = findViewById(R.id.view);
        gestureTypeTv = findViewById(R.id.gestureTypeTV);

        MyGestureListener listener =  new MyGestureListener();
        mDetector = new GestureDetector(this, listener);
        touchpad.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                mDetector.onTouchEvent(event);
                return true;
            }
        });

        /* Register Receiver*/
        /* Request permissions to access SMS */
        ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.SEND_SMS, android.Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS}, 0);
        /* Create and instantiate the local broadcast receiver
           This class listens to messages come from class SMSReceiver
         */
        myBroadCastReceiver = new EventActivity.MyBroadCastReceiver();

        /*
         * Register the broadcast handler with the intent filter that is declared in
         * class SMSReceiver @line 11
         * */
        registerReceiver(myBroadCastReceiver, new IntentFilter(SMSReceiver.SMS_FILTER), RECEIVER_EXPORTED);

        /* Setup Navigation Drawer, toolbar and floating action button*/
        drawerlayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerlayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerlayout.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(new EventActivity.MyNavigationListener());

        View view = findViewById(R.id.main);
        if (view != null) {
            ViewCompat.setOnApplyWindowInsetsListener(view, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        }
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onClickCreateNewEventCategory(view);
            }
        });

        /* Setup Gson and fragments */
        gson = new Gson();
        fragmentListCategory = new FragmentListCategory();
        fragmentManager = getSupportFragmentManager();

        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.fragmentContainerView2, fragmentListCategory);
        transaction.commit();
    }
    private class MyGestureListener extends GestureDetector.SimpleOnGestureListener {
        @Override
        public void onLongPress(@NonNull MotionEvent e) {
            gestureTypeTv.setText("OnLongPress");
            clear();
        }

        @Override
        public boolean onDoubleTap(@NonNull MotionEvent e) {
            gestureTypeTv.setText("OnDoubleTap");
            onClickCreateNewEventCategory(findViewById(android.R.id.content));
            return true;
        }
    }
    public void onClickCreateNewEventCategory(View view) {
        if (create()) {
            Snackbar.make(view, "Event saved successfully: " + etEventID.getText() + " to " + etCategoryID.getText().toString(), Snackbar.LENGTH_LONG)
                    .setAction("Undo", undoOnClickListener).show();
        }
    }
    private boolean create() {
        String activeStr = switchEventActive.isChecked() ? "true" : "false";
        String[] tokens = {etEventName.getText().toString(), etCategoryID.getText().toString(), etTicketAvailable.getText().toString(), activeStr};

        if (validateTokens(tokens)) {
            String eventID = generateEventID();
            etEventID.setText(eventID);
            saveDataToDatabase(eventID, etCategoryID.getText().toString(), etEventName.getText().toString(), Integer.parseInt(etTicketAvailable.getText().toString().isEmpty() ? "0" : etTicketAvailable.getText().toString()), switchEventActive.isChecked());
            return true;
        } else {
            Toast.makeText(getApplicationContext(), "Invalid category name or event count!", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    class MyBroadCastReceiver extends BroadcastReceiver {

        /*
         * This method 'onReceive' will get executed every time class SMSReceive sends a broadcast
         * */
        @Override
        public void onReceive(Context context, Intent intent) {
            /*
             * Retrieve the message from the intent
             * */
            String msg = intent.getStringExtra(SMSReceiver.SMS_MSG_KEY);
            /*
             * String Tokenizer is used to parse the incoming message
             * The protocol is to have the account holder name and account number separate by a semicolon
             * */

            checkBroadcastMessage(msg);

        }

    }

    private String generateEventID() {
        StringBuilder newEventID = new StringBuilder();
        Random randomizer = new Random();
        AtomicBoolean valid = new AtomicBoolean(false);

        while (!valid.get()) {
            valid.set(true);
            newEventID.append('E');
            for (int i = 0; i < 2; i++) {
                newEventID.append((char) (randomizer.nextInt(26) + 'A'));
            }
            newEventID.append('-');
            for (int i = 0; i < 5; i++) {
                newEventID.append((char) (randomizer.nextInt(10) + '0'));
            }
            eventViewModel.getAllEvent().observe(this, newData -> {
                for (Event event : eventViewModel.getAllEvent().getValue()) {
                    if (event.getEvent_id().equals(newEventID.toString())) {
                        valid.set(false);
                    }
                }
            });
        }
        return newEventID.toString();
    }

    private boolean validateTokens(String[] tokens) {
        for (int i = 0; i < tokens.length; i++)
            if (i == 0) {
                if (tokens[0].isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Event name should not be empty!", Toast.LENGTH_SHORT).show();
                    return false;
                } else if (!isAlphaOrAlphanumeric(tokens[0])) {
                    Toast.makeText(getApplicationContext(), "Invalid event name!", Toast.LENGTH_SHORT).show();
                    return false;
                }
            } else if (i == 1) {

                AtomicBoolean found_ID = new AtomicBoolean(false);
                categoryViewModel.getAllCategory().observe(this, newData -> {
                    for (EventCategory category : newData) {
                        if (tokens[1].equals(category.getCategory_id())) {
                            found_ID.set(true);
                            break;
                        }
                    }
                });

                if (tokens[1].isEmpty() || !found_ID.get()) {
                    Toast.makeText(getApplicationContext(), "Invalid category ID!", Toast.LENGTH_SHORT).show();
                    return false;
                }
            } else if (i == 2) {
                try {
                    if (!tokens[2].isEmpty() && Integer.parseInt(tokens[2]) <= 0) {
                        Toast.makeText(getApplicationContext(), "Tickets available should be positive!", Toast.LENGTH_SHORT).show();
                        return false;
                    }
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Invalid tickets avaible!", Toast.LENGTH_SHORT).show();
                    return false;
                }
            } else if (!(tokens[3].equalsIgnoreCase("true") || tokens[3].equalsIgnoreCase("false") || tokens[3].isEmpty())) {
                Toast.makeText(getApplicationContext(), "Invalid is active value!", Toast.LENGTH_SHORT).show();
                return false;
            }
        return true;
    }

//    private void saveDataToSharedPreference(String eventID, String categoryID, String eventName, int ticketAvailable, boolean active) {
//        SharedPreferences sharedPreferences = getSharedPreferences(KeyStore.FILE_NAME, MODE_PRIVATE);
//
//        SharedPreferences.Editor editor = sharedPreferences.edit();
//
//        int color = Color.BLACK;
//        for (EventCategory category : listCategories) {
//            if (category.getCategory_id().equals(categoryID)) {
//                color = category.getColor();
//                break;
//            }
//        }
//
//        Event newEvent = new Event(eventID, categoryID, eventName, ticketAvailable, active, color);
//
//        listEvents.add(newEvent);
//
//        String arrayListString = gson.toJson(listEvents);
//
//        editor.putString(KeyStore.KEY_EVENT_ARRAYLIST, arrayListString);
//
//        arrayListString = gson.toJson(default_category_list);
//        String arrayListStringRestored = sharedPreferences.getString(KeyStore.KEY_CATEGORY_ARRAYLIST, arrayListString);
//        Type type = new TypeToken<ArrayList<EventCategory>>() {}.getType();
//        listCategories = gson.fromJson(arrayListStringRestored, type);
//
//        for (EventCategory category : listCategories) {
//            if (category.getCategory_id().equals(categoryID)) {
//                category.incrementEventCount();
//            }
//        }
//
//        arrayListString = gson.toJson(listCategories);
//
//        editor.putString(KeyStore.KEY_CATEGORY_ARRAYLIST, arrayListString);
//        editor.apply();
//        onClickRefresh();
//
//
//    }

    private void saveDataToDatabase(String eventID, String categoryID, String eventName, int ticketAvailable, boolean active) {
        AtomicInteger color = new AtomicInteger(Color.BLACK);
        AtomicBoolean incremented = new AtomicBoolean(false);
        categoryViewModel.getAllCategory().observe(this, newData -> {
            Log.v("TAG", newData.toString());
            if (!incremented.get()) {
                for (EventCategory category : newData) {
                    if (category.getCategory_id().equals(categoryID)) {
                        color.set(category.getColor());
                        categoryViewModel.incrementEventCount(categoryID);
                        incremented.set(true);
                        break;
                    }
                }
            }
        });


        Event newEvent = new Event(eventID, categoryID, eventName, ticketAvailable, active, color.get());
        eventViewModel.insert(newEvent);
        lastEventStored = eventID;

        onClickRefresh();
    }
//    public void restoreArrayListAsText() {
//        SharedPreferences sharedPreferences = getSharedPreferences(KeyStore.FILE_NAME, MODE_PRIVATE);
//        String arrayListStringRestored = sharedPreferences.getString(KeyStore.KEY_EVENT_ARRAYLIST, "[]");
//        Type type = new TypeToken<ArrayList<Event>>() {
//        }.getType();
//        listEvents = gson.fromJson(arrayListStringRestored, type);
//
//        String arrayListString = gson.toJson(default_category_list);
//        arrayListStringRestored = sharedPreferences.getString(KeyStore.KEY_CATEGORY_ARRAYLIST, arrayListString);
//        type = new TypeToken<ArrayList<EventCategory>>() {}.getType();
//        listCategories = gson.fromJson(arrayListStringRestored, type);
//    }

    public void onClickBack(View view) {
        Intent resultIntent = new Intent();
        setResult(Activity.RESULT_OK, resultIntent);
        finish();
    }

    private void checkBroadcastMessage(String msg) {
        String[] tokens = new String[4];
        String[] temp = msg.split(":");
        if (!temp[0].equals("event") || !msg.contains(":")) {
            Toast.makeText(getApplicationContext(), "Message should begin with 'event'!", Toast.LENGTH_SHORT).show();
            return;
        } else {
            tokens = temp[1].split(";");

            if (tokens.length != 4) {
                Toast.makeText(getApplicationContext(), "Invalid message format!", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        if (validateTokens(tokens)) {
            etEventName.setText(tokens[0]);
            etCategoryID.setText(tokens[1]);
            etTicketAvailable.setText(tokens[2]);
            switchEventActive.setChecked(tokens[3].equalsIgnoreCase("true"));
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu, menu);
        return true;
    }

    View.OnClickListener undoOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            try {
//                Event eventRemoved = listEvents.get(listEvents.size() - 1);
//                listEvents.remove(listEvents.size() - 1);
//
//                SharedPreferences sharedPreferences = getSharedPreferences(KeyStore.FILE_NAME, MODE_PRIVATE);
//                SharedPreferences.Editor editor = sharedPreferences.edit();
//                String arrayListString = gson.toJson(listEvents);
//                editor.putString(KeyStore.KEY_EVENT_ARRAYLIST, arrayListString);
//
//                arrayListString = gson.toJson(default_category_list);
//                String arrayListStringRestored = sharedPreferences.getString(KeyStore.KEY_CATEGORY_ARRAYLIST, arrayListString);
//                Type type = new TypeToken<ArrayList<EventCategory>>() {}.getType();
//                listCategories = gson.fromJson(arrayListStringRestored, type);
//                for (EventCategory category : listCategories) {
//                    if (category.getCategory_id().equals(eventRemoved.getCategory_id())) {
//                        category.decrementEventCount();
//
//                        break;
//                    }
//                }
//
//                arrayListString = gson.toJson(listCategories);
//
//                editor.putString(KeyStore.KEY_CATEGORY_ARRAYLIST, arrayListString);
//
//                editor.apply();

                categoryViewModel.decrementEventCount(getID());
                eventViewModel.deleteEvent(lastEventStored);

                onClickRefresh();
            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "No events to remove!", Toast.LENGTH_SHORT).show();
            }
        }
    };
    private String getID() {
        AtomicReference<String> categoryID = new AtomicReference<>("");
        eventViewModel.getAllEvent().observe(this, newData -> {
            for (Event event : newData) {
                if (event.getEvent_id().equals(lastEventStored)) {
                    categoryID.set(event.getCategory_id());
                    break;
                }
            }

        });
        return categoryID.get();
    }
//    @Override
//    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
//        SharedPreferences sharedPreferences = getSharedPreferences(KeyStore.FILE_NAME, MODE_PRIVATE);
//        SharedPreferences.Editor editor = sharedPreferences.edit();
//        String arrayListStringRestored = sharedPreferences.getString(KeyStore.KEY_EVENT_ARRAYLIST, "[]");
//        Type type = new TypeToken<ArrayList<Event>>() {}.getType();
//        listEvents = gson.fromJson(arrayListStringRestored, type);
//
//        String arrayListString = gson.toJson(default_category_list);
//        arrayListStringRestored = sharedPreferences.getString(KeyStore.KEY_CATEGORY_ARRAYLIST, arrayListString);
//        type = new TypeToken<ArrayList<EventCategory>>() {}.getType();
//        listCategories = gson.fromJson(arrayListStringRestored, type);
//
//
//        if (item.getItemId() == R.id.refresh) {
//            onClickRefresh();
//            // call refresh method here
//
//        } else if (item.getItemId() == R.id.clear) {
//            etCategoryID.setText("");
//            etEventID.setText("");
//            etEventName.setText("");
//            etTicketAvailable.setText("");
//            switchEventActive.setChecked(false);
//        } else if (item.getItemId() == R.id.delete_category) {
//            listCategories = new ArrayList<EventCategory>();
//            EventCategory e = new EventCategory("", "", 0, false);
//            e.setHeader();
//            listCategories.add(e);
//
//            arrayListString = gson.toJson(default_category_list);
//            editor.putString(KeyStore.KEY_CATEGORY_ARRAYLIST, arrayListString);
//            editor.apply();
//            onClickRefresh();
//        } else if (item.getItemId() == R.id.delete_event) {
//            for (Event event : listEvents) {
//                for (EventCategory category : listCategories) {
//                    if (category.getCategory_id().equals(event.getCategory_id())) {
//                        category.decrementEventCount();
//                        break;
//                    }
//                }
//            }
//
//            listEvents = new ArrayList<Event>();
//            arrayListString = gson.toJson(listEvents);
//
//            editor.putString(KeyStore.KEY_EVENT_ARRAYLIST, arrayListString);
//
//            arrayListString = gson.toJson(listCategories);
//
//            editor.putString(KeyStore.KEY_CATEGORY_ARRAYLIST, arrayListString);
//            editor.apply();
//            onClickRefresh();
//        }
//        return true;
//    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.refresh) {
            onClickRefresh();
            // call refresh method here

        } else if (item.getItemId() == R.id.clear) {
            clear();
        } else if (item.getItemId() == R.id.delete_category) {
            categoryViewModel.deleteAllCategory();
            onClickRefresh();
        } else if (item.getItemId() == R.id.delete_event) {
            AtomicBoolean stopper = new AtomicBoolean(false);
            eventViewModel.getAllEvent().observe(this, newData -> {
                Log.v("ur mtoher", newData.toString());
                if (!stopper.get()) {
                    for (Event event : newData) {
                        categoryViewModel.decrementEventCount(event.getCategory_id());
                    }
                    stopper.set(true);
                }
            });

            eventViewModel.deleteAllEvent();
            onClickRefresh();
        }
        return true;
    }
    class MyNavigationListener implements NavigationView.OnNavigationItemSelectedListener {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            // get the id of the selected item
            int id = item.getItemId();

            if (id == R.id.view_all_categories) {
                // Do something
                Intent intent_user_details = new Intent(getApplicationContext(), ListCategoryActivity.class);

                startActivity(intent_user_details);
            } else if (id == R.id.add_category) {
                // Do something
                Intent intent_user_details = new Intent(getApplicationContext(), EventCategoryActivity.class);
                registerReceiver(myBroadCastReceiver, new IntentFilter(SMSReceiver.SMS_FILTER), RECEIVER_EXPORTED);
                unregisterReceiver(myBroadCastReceiver);
                startActivity(intent_user_details);
            } else if (id == R.id.view_all_events) {
                // Do something sussy
                Intent intent_user_details = new Intent(getApplicationContext(), ListEventActivity.class);

                startActivity(intent_user_details);
            } else if (id == R.id.logout) {
                // Do even sussier stuff
                finish();
            }
            // close the drawer
            drawerlayout.closeDrawers();
            // tell the OS
            return true;
        }
    }

    public boolean isAlphaOrAlphanumeric(String str) {
        boolean hasAlphabetic = false;
        for (char c : str.toCharArray()) {
            if (Character.isLetter(c)) {
                hasAlphabetic = true;
            } else if (!Character.isDigit(c) && c != ' ') {
                return false;
            }
        }
        return hasAlphabetic;
    }

    public void onClickRefresh() {
        registerReceiver(myBroadCastReceiver, new IntentFilter(SMSReceiver.SMS_FILTER), RECEIVER_EXPORTED);
        FragmentListCategory fragmentListCategory = (FragmentListCategory) getSupportFragmentManager().findFragmentById(R.id.fragmentContainerView2);
        fragmentListCategory.refresh();
    }
    public void clear() {
        etCategoryID.setText("");
        etEventID.setText("");
        etEventName.setText("");
        etTicketAvailable.setText("");
        switchEventActive.setChecked(false);
    }
}
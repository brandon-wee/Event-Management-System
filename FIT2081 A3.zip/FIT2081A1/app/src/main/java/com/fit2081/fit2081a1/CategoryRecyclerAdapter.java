package com.fit2081.fit2081a1;

import android.content.Intent;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.fit2081.fit2081a1.provider.EventCategory;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;

public class CategoryRecyclerAdapter extends RecyclerView.Adapter<CategoryRecyclerAdapter.CustomViewHolder> {

    ArrayList<EventCategory> data = new ArrayList<EventCategory>();
    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.category_card_layout, parent, false);
        CustomViewHolder viewHolder = new CustomViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder holder, int position) {
        Log.v("TAG", data.get(position).toString());
        if (!data.get(position).isHeader()) {
            holder.tvCategoryID.setText(data.get(position).getCategory_id());
            holder.tvCategoryName.setText(data.get(position).getCategory_name());
            holder.tvEventCount.setText(String.valueOf(data.get(position).getEvent_count()));

            if (data.get(position).isIs_active()) {
                holder.tvIsActive.setText("Yes");
            } else {
                holder.tvIsActive.setText("No");
            }

            holder.tvColor.setBackgroundColor(data.get(position).getColor());
            holder.location = data.get(position).getLocation();
        } else {
            holder.tvCategoryID.setText("ID");
            holder.tvCategoryName.setText("Name");
            holder.tvEventCount.setText("Event Count");
            holder.tvIsActive.setText("Active?");

            holder.tvCategoryID.setTextColor(Color.WHITE);
            holder.tvCategoryName.setTextColor(Color.WHITE);
            holder.tvEventCount.setTextColor(Color.WHITE);
            holder.tvIsActive.setTextColor(Color.WHITE);

            holder.tvColor.setBackgroundColor(Color.DKGRAY);
            holder.cardView.setCardBackgroundColor(Color.DKGRAY);
        }
        final int fPosition = position;
        holder.itemView.setOnClickListener(new View.OnClickListener() { //set back to itemView for students
            @Override
            public void onClick(View v) {
                if (fPosition > 0) {
                    Intent intent_user_details = new Intent(v.getContext(), CategoryMapsActivity.class);
                    intent_user_details.putExtra("location", data.get(position).getLocation());

                    v.getContext().startActivity(intent_user_details);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        if (this.data != null) { // if data is not null
            return this.data.size(); // then return the size of ArrayList
        }

        // else return zero if data is null
        return 0;
    }

    public void setData(ArrayList<EventCategory> data) {
        this.data = data;
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder {

        public TextView tvCategoryID;
        public TextView tvCategoryName;
        public TextView tvEventCount;
        public TextView tvIsActive;
        public TextView tvColor;
        public CardView cardView;
        public String location;
        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);
            tvCategoryID = itemView.findViewById(R.id.tv_category_id);
            tvCategoryName = itemView.findViewById(R.id.tv_category_name);
            tvEventCount = itemView.findViewById(R.id.tv_event_count);
            tvIsActive = itemView.findViewById(R.id.tv_category_active);
            tvColor = itemView.findViewById(R.id.category_color_strip);
            cardView = itemView.findViewById(R.id.category_card);
        }
    }
}
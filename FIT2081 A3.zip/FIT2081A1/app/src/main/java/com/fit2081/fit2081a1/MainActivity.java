package com.fit2081.fit2081a1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText etUsername;
    EditText etPassword;
    EditText etConfirmPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUsername = findViewById(R.id.editTextUsername);
        etPassword = findViewById(R.id.editTextPassword);
        etConfirmPassword = findViewById(R.id.editTextConfirmPassword);
    }

    public void onClickSignUp(View view) {
        String str_username = "", str_password = "", str_confirm_password = "";

        str_username = etUsername.getText().toString();
        str_password = etPassword.getText().toString();
        str_confirm_password = etConfirmPassword.getText().toString();

        if (str_username.isEmpty() || str_password.isEmpty() || str_confirm_password.isEmpty()) {
            Toast.makeText(getApplicationContext(), "Sign up unsuccessfully! Please try again!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (str_password.equals(str_confirm_password)) {
            Toast.makeText(getApplicationContext(), "Signed up successfully! Redirecting to login page!", Toast.LENGTH_SHORT).show();

            // save data to shared preferences
            saveDataToSharedPreference(str_username, str_password);

            handleLogin(view);

        } else {
            Toast.makeText(getApplicationContext(), "Passwords do not match! Please try again!", Toast.LENGTH_SHORT).show();
            return;
        }
    }

    private void saveDataToSharedPreference(String username, String password){
        SharedPreferences sharedPreferences = getSharedPreferences(KeyStore.FILE_NAME, MODE_PRIVATE);

        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putString(KeyStore.KEY_USERNAME, username);
        editor.putString(KeyStore.KEY_PASSWORD, password);
        editor.putString(KeyStore.KEY_CATEGORY_ID, "-");
        editor.putString(KeyStore.KEY_EVENT_ID, "-");
        editor.apply();

    }

    public void handleLogin(View view) {
        Intent intent_user_details = new Intent(getApplicationContext(), LoginActivity.class);

        startActivity(intent_user_details);
    }
}
package com.fit2081.fit2081a1;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class DashboardActivity extends AppCompatActivity {

    TextView tvEventCategoryID;
    TextView tvEventID;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        tvEventCategoryID = findViewById(R.id.textViewEventCategory);
        tvEventID = findViewById(R.id.textViewEvent);

        SharedPreferences sharedPreferences = getSharedPreferences(KeyStore.FILE_NAME, MODE_PRIVATE);

        // save key-value pairs to the shared preference file
        String categoryIDRestored = sharedPreferences.getString(KeyStore.KEY_CATEGORY_ID, "-");
        String eventIDRestored = sharedPreferences.getString(KeyStore.KEY_EVENT_ID, "-");

        tvEventCategoryID.setText(categoryIDRestored);
        tvEventID.setText(eventIDRestored);
    }

    public void onClickNewCategory(View view) {
        Intent intent_user_details = new Intent(getApplicationContext(), EventCategoryActivity.class);

        startActivityForResult(intent_user_details, 1);

    }

    public void onClickNewEvent(View view) {
        Intent intent_user_details = new Intent(getApplicationContext(), EventActivity.class);

        startActivityForResult(intent_user_details, 2);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK) {
            SharedPreferences sharedPreferences = getSharedPreferences(KeyStore.FILE_NAME, MODE_PRIVATE);
            String categoryIDRestored = sharedPreferences.getString(KeyStore.KEY_CATEGORY_ID, "-");
            tvEventCategoryID.setText(categoryIDRestored);
        } else if (requestCode == 2 && resultCode == RESULT_OK) {
            SharedPreferences sharedPreferences = getSharedPreferences(KeyStore.FILE_NAME, MODE_PRIVATE);
            String eventIDRestored = sharedPreferences.getString(KeyStore.KEY_EVENT_ID, "-");
            tvEventID.setText(eventIDRestored);
        }
    }
}
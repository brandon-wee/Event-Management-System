package com.fit2081.fit2081a1.provider;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.DatabaseConfiguration;
import androidx.room.InvalidationTracker;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteOpenHelper;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@androidx.room.Database(entities = {Event.class, EventCategory.class}, version = 1)
public abstract class A3Database extends RoomDatabase{
    public static final String DATABASE_NAME = "A3_DATABASE";
    public abstract EventDao eventDao();
    public abstract EventCategoryDao categoryDao();
    private static final int NUMBER_OF_THREADS = 4;

    static final ExecutorService databaseWriteExecutor = Executors.newFixedThreadPool(NUMBER_OF_THREADS);
    private static volatile A3Database INSTANCE;
    static A3Database getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (A3Database.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(), A3Database.class, DATABASE_NAME).build();
                }
            }
        }
        return INSTANCE;
    }
}
